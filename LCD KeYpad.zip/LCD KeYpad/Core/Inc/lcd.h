/****************************************************/
/*  lcd_driver.h                                    */
/*                                                  */
/*  Created on: Dec 6 , 2023                        */
/*  Author: Ashirbad Roul						    */
/****************************************************/

#ifndef INC_LCD_DRIVER_H_
#define INC_LCD_DRIVER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"


/* Ports and Pins for RS, RW, En, D4 TO D7 */
#define RS_PORT GPIOA
#define RS_PIN GPIO_PIN_0
#define RW_PORT GPIOA
#define RW_PIN GPIO_PIN_1
#define EN_PORT GPIOA
#define EN_PIN GPIO_PIN_4
#define D0_PORT GPIOB
#define D0_PIN GPIO_PIN_8
#define D1_PORT GPIOB
#define D1_PIN GPIO_PIN_9
#define D2_PORT GPIOA
#define D2_PIN GPIO_PIN_6
#define D3_PORT GPIOA
#define D3_PIN GPIO_PIN_7
#define D4_PORT GPIOB
#define D4_PIN GPIO_PIN_6
#define D5_PORT GPIOB
#define D5_PIN GPIO_PIN_7
#define D6_PORT GPIOA
#define D6_PIN GPIO_PIN_9
#define D7_PORT GPIOA
#define D7_PIN GPIO_PIN_8
#define ADC_PORT GPIOC
#define ADC_PIN GPIO_PIN_2


/* Function to initialize LCD */
void LCD_Init(void);

/* Function to send commands to LCD */
void LCD_Send_cmd(uint8_t cmd);

/* Function to send data to LCD */
void LCD_Send_data(uint8_t data);

/* Function to send text to LCD */
void LCD_Send_string(char *str);

void lcd_display_temperature(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_LCD_DRIVER_H_ */
