/****************************************************/
/*  lcd_driver.c                                    */
/*                                                  */
/*  Created on: Dec 6 , 2023                        */
/*  Author: Ashirbad Roul					    	*/
/****************************************************/

#include <stdio.h>
#include "lcd.h"
#include "stm32f4xx_hal.h"



void LCD_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;

	/* Initialize RS as output push-pull */
	GPIO_InitStruct.Pin = RS_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(RS_PORT, &GPIO_InitStruct);

	/* Initialize EN as output push-pull */
	GPIO_InitStruct.Pin = EN_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(EN_PORT, &GPIO_InitStruct);

	/* Initialize D0 pin as output push-pull */
	GPIO_InitStruct.Pin = D0_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(D0_PORT, &GPIO_InitStruct);

	/* Initialize D1 pin as output push-pull */
	GPIO_InitStruct.Pin = D1_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(D1_PORT, &GPIO_InitStruct);

	/* Initialize D2 pin as output push-pull */
	GPIO_InitStruct.Pin = D2_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(D2_PORT, &GPIO_InitStruct);

	/* Initialize D3 pin as output push-pull */
	GPIO_InitStruct.Pin = D3_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(D3_PORT, &GPIO_InitStruct);

	/* Initialize D4 pin as output push-pull */
	GPIO_InitStruct.Pin = D4_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(D4_PORT, &GPIO_InitStruct);

	/* Initialize D5 pin as output push-pull */
	GPIO_InitStruct.Pin = D5_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(D5_PORT, &GPIO_InitStruct);

	/* Initialize D6 pin as output push-pull */
	GPIO_InitStruct.Pin = D6_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(D6_PORT, &GPIO_InitStruct);

	/* Initialize D7 pin as output push-pull */
	GPIO_InitStruct.Pin = D7_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(D7_PORT, &GPIO_InitStruct);

	HAL_Delay(50);

	/* Send initialization commands to LCD */

	HAL_Delay(50);  // wait for >40ms
	LCD_Send_cmd (0x30);
	HAL_Delay(5);  // wait for >4.1ms
	LCD_Send_cmd (0x30);
	HAL_Delay(1);  // wait for >100us
	LCD_Send_cmd (0x30);
	HAL_Delay(10);

	/* 8-bit mode, 2-line display, 5x8 font */
	LCD_Send_cmd(0x38);
	LCD_Send_cmd (0x08);
	HAL_Delay(100);
	LCD_Send_cmd (0x01);
	HAL_Delay(100);
	HAL_Delay(100);
	LCD_Send_cmd (0x06);
	LCD_Send_cmd (0x0C);

	/* Display on, cursor off, blink off */
	/*LCD_Send_cmd(0x0C);

	/*LCD_Send_cmd(0x01);
	HAL_Delay(2);
	*/
}

void LCD_Send_cmd(uint8_t cmd)
{
	/* Set RS pin to 0 to send command */
	HAL_GPIO_WritePin(RS_PORT, RS_PIN, GPIO_PIN_RESET);

	/* Send command byte to data pins */
	HAL_GPIO_WritePin(D0_PORT, D0_PIN, (cmd & 0x01));
	HAL_GPIO_WritePin(D1_PORT, D1_PIN, (cmd & 0x02));
	HAL_GPIO_WritePin(D2_PORT, D2_PIN, (cmd & 0x04));
	HAL_GPIO_WritePin(D3_PORT, D3_PIN, (cmd & 0x08));
	HAL_GPIO_WritePin(D4_PORT, D4_PIN, (cmd & 0x10));
	HAL_GPIO_WritePin(D5_PORT, D5_PIN, (cmd & 0x20));
	HAL_GPIO_WritePin(D6_PORT, D6_PIN, (cmd & 0x40));
	HAL_GPIO_WritePin(D7_PORT, D7_PIN, (cmd & 0x80));

	/* Pulse EN pin to latch command byte */
	HAL_GPIO_WritePin(EN_PORT, EN_PIN, GPIO_PIN_SET);
	HAL_Delay(1);

	HAL_GPIO_WritePin(EN_PORT, EN_PIN, GPIO_PIN_RESET);
	HAL_Delay(1);
}

void LCD_Send_data(uint8_t data)
{
	/* Set RS pin to 1 to send data */
	HAL_GPIO_WritePin(RS_PORT, RS_PIN, GPIO_PIN_SET);
	/* Send data byte to data pins */
	HAL_GPIO_WritePin(D0_PORT, D0_PIN, (data & 0x01));
	HAL_GPIO_WritePin(D1_PORT, D1_PIN, (data & 0x02));
	HAL_GPIO_WritePin(D2_PORT, D2_PIN, (data & 0x04));
	HAL_GPIO_WritePin(D3_PORT, D3_PIN, (data & 0x08));
	HAL_GPIO_WritePin(D4_PORT, D4_PIN, (data & 0x10));
	HAL_GPIO_WritePin(D5_PORT, D5_PIN, (data & 0x20));
	HAL_GPIO_WritePin(D6_PORT, D6_PIN, (data & 0x40));
	HAL_GPIO_WritePin(D7_PORT, D7_PIN, (data & 0x80));

	/* Pulse EN pin to latch command byte */
	HAL_GPIO_WritePin(EN_PORT, EN_PIN, GPIO_PIN_SET);
	HAL_Delay(1);

	HAL_GPIO_WritePin(EN_PORT, EN_PIN, GPIO_PIN_RESET);
	HAL_Delay(1);
}

void LCD_Send_string(char *str)
{
	/* Send each character of the string to the LCD */
	while (*str)
	{
		LCD_Send_data(*str++);
	}
}

